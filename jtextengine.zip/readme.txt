JTextEngine - a Java text adventure engine.
by Christian Bartsch (s1410629001)
and Stefan Niederhumer (s1410629014)

Contents of this zip file:

src: Java sources of the JText engine, main and unit tests (src/jtextengine/main and src/jtextengine/texst) and the console UI app (src/jtextconsole/src)

docs: Documentation PDFs: Logbook (log.pdf), class diagram (classdiagram.pdf) and use cases (usecases.pdf).

game: Game executable (start.bat runs the provided test game).